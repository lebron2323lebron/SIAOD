#include "dataStructures.cpp"
#include "tasks.cpp"

using namespace std;

int main()
{
    setlocale(LC_ALL, "Russian");

    task1();

    task2();

    task3();

    task4();

    task5();

    task6();

    task7();

    task8();

    return 0;
}
